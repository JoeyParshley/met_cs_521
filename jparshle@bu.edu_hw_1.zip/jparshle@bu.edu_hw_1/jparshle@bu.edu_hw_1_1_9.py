'''
	Chapter 1 problem: 1.9
	
	Display to the console the area and perimiter of a rectangle
	with a width of 4.5 and length of 7.9 using the formulas
		area = width * height
		perimeter = 2 * ( length + width )
'''
print("\n")
print("Area of rectangle with width of 4.5 and length of 7.9:")
print(4.5 * 7.9)
print("\n")
print("Area of perimeter with width of 4.5 and length of 7.9:")
print(2 * ( 4.5 + 7.9))
print("\n")
