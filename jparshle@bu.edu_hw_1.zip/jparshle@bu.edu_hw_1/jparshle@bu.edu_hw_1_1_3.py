'''
	Chapter 1 problem: 1.3

	Display the following pattern to the console:
	FFFFFFF   U     U   NN     NN
	FF        U     U   NNN    NN
	FFFFFFF   U     U   NN N   NN
    FF         U   U    NN  N  NN
    FF          UUU     NN    NNN

    Note: printing "\n" to create some space in the console
'''
print("\n")
print("FFFFFFF   U     U   NN     NN")
print("FF        U     U   NNN    NN")
print("FFFFFFF   U     U   NN N   NN")
print("FF         U   U    NN  N  NN")
print("FF          UUU     NN    NNN")
print("\n")
