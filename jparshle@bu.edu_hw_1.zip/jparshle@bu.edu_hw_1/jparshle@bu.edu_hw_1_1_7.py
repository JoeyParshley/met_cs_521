'''
	Chapter 1 problem: 1.7
	
	Display to the console the result of these equations estimating pi
		4 * ( 1 - 1/3 + 1/5 - 1/7 + 1/9 - 1/11 )
		4 * ( 1 - 1/3 + 1/5 - 1/7 + 1/9 - 1/11 + 1/13 - 1/15 )
'''
print("\n")
print("Result of '4 * ( 1 - 1/3 + 1/5 - 1/7 + 1/9 - 1/11 )':")
print( 4 * ( 1 - (1/3) + (1/5) - (1/7) + (1/9) - (1/11) ))
print("Result of '4 * ( 1 - 1/3 + 1/5 - 1/7 + 1/9 - 1/11 + 1/13 - 1/15 )':")
print( 4 * ( 1 - (1/3) + (1/5) - (1/7) + (1/9) - (1/11) + (1/13) - (1/15) ))
print("\n")
