'''
	Chapter 1 problem: 1.5
	
	Display to the console, the result of the following equation
		9.5×4.5−2.5×3 / 45.5−3.5

	Note: I am printing the result of the equation as is verbatim
	in actuality I would have grouped the calculations to better understand
	the order of operations. i.e. ( ( 9.5 * 4.5 ) - ( 2.5 * 3 ) ) / ( 45.5 - 3.5 )
'''
print("\n")
print( 9.5 * 4.5 - 2.5 * 3 / 45.5 - 3.5 )
print("\n")
