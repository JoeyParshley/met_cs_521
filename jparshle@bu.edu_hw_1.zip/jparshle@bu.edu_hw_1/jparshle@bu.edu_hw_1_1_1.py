'''
	Chapter 1 problem: 1.1
	
	Display three differen messages:
	(Welcome to Python , Welcome to Computer Science , and Programming is fun)
	to the console on separate lines

    Note: printing "\n" to create some space in the console
'''
print("\n")
print("Welcome to Python")
print("Welcome to Computer Science")
print("Programming is fun")
print("\n")
