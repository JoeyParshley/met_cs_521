"""
   Joey Parshley
   MET CS 521 O2
   17 APR 2018
   hw_6_7_1
   Description: 

"""